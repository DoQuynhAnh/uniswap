## Description

Intended for a few utils shared usage from our Cloudflare /functions utils to /src, since `functions` is treated as a separate project from the main `src` project that relies on different libraries and uses slightly different typings.
