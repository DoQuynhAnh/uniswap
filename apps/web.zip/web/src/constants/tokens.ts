// eslint-disable-next-line no-restricted-syntax
export const NATIVE_CHAIN_ID = 'NATIVE'
export const UNKNOWN_TOKEN_SYMBOL = 'UNKNOWN'
