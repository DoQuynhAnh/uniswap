export type SVGProps = React.SVGProps<SVGSVGElement>
