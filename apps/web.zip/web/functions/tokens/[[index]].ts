// Keep rich link previews for legacy /tokens URL.
export { onRequest } from '../explore/tokens/[[index]]'
