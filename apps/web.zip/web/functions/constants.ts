export const WATERMARK_URL = 'https://app.uniswap.org/images/324x74_App_Watermark.png'
